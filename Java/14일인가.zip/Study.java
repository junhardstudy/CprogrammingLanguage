class Resistor{
	double resistance;
	
	Resistor(){}
	Resistor(double resistance){
		this.resistance = resistance;
	}
}

class Circuit extends Resistor{
	int width;
	
	
}

class Desktop extends Circuit{
	
}

class MobilePhone extends Circuit{
	
}

class Study{
	public static void main(String [] args){
		
	}
}
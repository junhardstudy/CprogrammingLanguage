class Ref{
	public static void main(String [] args){
		int [] arr = {1, 2, 3, 4, 5};
		int[][] arr2 = {{1, 15, 53}, {2, 6, 5}};//���� ���� �߰�ȣ�� ����.
		System.out.println(arr2[0][1]);
		
		for(int i = 0 ; i < arr2.length ; i++){
			for(int j = 0; j < arr2[0].length ; j++)System.out.print(arr2[i][j] + "\t");
			//arr2[0].length �� ���� ����
			System.out.println();
		}
		
	
/*
		for(int i = 0; i < arr.length; i++){
			arr[i] = arr[i] * 100;
		}
		*/
		
	//	for(int tmp:arr)tmp *= tmp;
		
				
	//	for(int i = 0; i < arr.length; i++)System.out.println(arr[i]);
		
		
		
		
		
	}
}